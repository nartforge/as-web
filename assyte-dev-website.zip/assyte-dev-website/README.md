# Assyte Dev Website

Assyte Dev markası için premium kalitede, sade, modern ve responsive web sitesi. Discord topluluğu, ürünler, mağaza, wiki ve destek sistemi üzerine kurulmuştur.

## Özellikler

- **5 Sayfa**: Ana Sayfa, Mağaza, Ürünler, Wiki, Destek
- **AMOLED Dark Mode**: #000000 tabanlı gerçek siyah tema
- **Light Mode**: Temiz ve ferah beyaz tema
- **Tema Desteği**: Butonla değiştirme, localStorage ile kalıcı kayıt
- **Responsive**: Mobil, tablet ve masaüstü uyumlu
- **Animasyonlar**: Scroll reveal, hover efektleri, yumuşak geçişler
- **Discord Entegrasyonu**: Tüm sayfalarda Discord CTA butonları
- **SEO**: Meta title, description ve Open Graph etiketleri

## Kurulum

```bash
# Bağımlılıkları yükle
npm install

# Geliştirme sunucusunu başlat (http://localhost:3000)
npm run dev

# Production build
npm run build

# Build'i önizle
npm run preview
```

## Dosya Yapısı

```
assyte-dev-website/
├── index.html              # HTML giriş noktası
├── package.json            # Bağımlılıklar ve scriptler
├── vite.config.ts          # Vite yapılandırması
├── tsconfig.json           # TypeScript yapılandırması
├── README.md               # Bu dosya
├── public/
│   └── favicon.svg         # Favicon (turkuaz/mavi gradient A logosu)
└── src/
    ├── main.tsx            # React giriş noktası
    ├── App.tsx             # Router ve layout
    ├── styles/
    │   └── index.css       # Global stiller, CSS değişkenleri, tema
    ├── context/
    │   └── ThemeContext.tsx # Tema yönetimi (light/dark)
    ├── hooks/
    │   └── useScrollAnimation.ts  # Intersection Observer hook
    ├── components/
    │   ├── Header.tsx      # Sabit navigasyon (sticky header)
    │   ├── Footer.tsx      # Sayfa altı linkler
    │   ├── DiscordCTA.tsx  # Discord'a yönlendirme butonu
    │   ├── ProductCard.tsx # Ürün kartı bileşeni
    │   └── ScrollReveal.tsx # Scroll animasyon wrapper
    ├── pages/
    │   ├── Home.tsx        # Ana sayfa (Hero, Discord CTA, özellikler)
    │   ├── Store.tsx       # Mağaza (ürün kartları)
    │   ├── Products.tsx    # Ürünler (filtreli, detaylı liste)
    │   ├── Wiki.tsx        # Wiki (kategori menüsü + içerik)
    │   └── Support.tsx     # Destek (kartlar + iletişim formu)
    └── data/
        ├── products.ts     # Ürün verileri
        └── wiki.ts         # Wiki makaleleri
```

## Tema Sistemi

- **Light Mode**: `#FFFFFF` arka plan, slate tonları, mavi/turkuaz aksan
- **Dark Mode**: `#000000` arka plan (AMOLED), `#0A0A0A` kartlar, `#1A1A1A` kenarlıklar
- **Değiştirme**: Header'daki butonla yapılır
- **Kalıcılık**: `localStorage`'da `assyte-theme` anahtarıyla saklanır
- **Renk Paleti**:
  - Birincil: `#0EA5E9` (Sky Blue)
  - İkincil: `#14B8A6` (Teal)
  - Gradient: `#0EA5E9` → `#14B8A6`

## Sayfalar

| Sayfa      | Rota        | Açıklama                              |
|------------|-------------|---------------------------------------|
| Ana Sayfa  | `/`         | Discord CTA, öne çıkan ürünler, istatistikler |
| Mağaza     | `/magaza`   | Ürün kartları, Discord'a yönlendirme  |
| Ürünler    | `/urunler`  | Kategori filtreli, detaylı ürün listesi |
| Wiki       | `/wiki`     | Kategori menülü dokümantasyon sayfası  |
| Destek     | `/destek`   | Destek kartları, iletişim formu       |

## Geliştirme Notları

- Pure React + TypeScript, ek UI kütüphanesi yok
- CSS değişkenleri ile tema yönetimi (CSS-in-JS yok)
- HashRouter kullanılmadı — BrowserRouter ile çalışır
- Backend gerektirmez, tamamen statik
- Tüm Discord linkleri `https://discord.gg/assytedev` adresine yönlendirir
- Form backend'i yoktur, örnek amaçlıdır
- React Router v6 ile sayfa yönlendirmeleri
- Vite ile hızlı geliştirme ve build

## Lisans

© 2024 Assyte Dev. Tüm hakları saklıdır.
