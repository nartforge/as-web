import { useState } from 'react'
import ScrollReveal from '../components/ScrollReveal'
import DiscordCTA from '../components/DiscordCTA'
import { products, categories } from '../data/products'

const statusLabels: Record<string, { label: string; className: string }> = {
  'active': { label: 'Aktif', className: 'tag-success' },
  'beta': { label: 'Beta', className: 'tag-warning' },
  'coming-soon': { label: 'Çok Yakında', className: 'tag-muted' },
}

const categoryLabels: Record<string, string> = {
  'discord-plugin': 'Discord Pluginleri',
  'minecraft': 'Minecraft Sistemleri',
  'web': 'Web Çözümleri',
  'custom': 'Özel Yazılım',
}

export default function Products() {
  const [activeCategory, setActiveCategory] = useState('all')
  const [expanded, setExpanded] = useState<string | null>(null)

  const filtered = activeCategory === 'all'
    ? products
    : products.filter(p => p.category === activeCategory)

  return (
    <div className="page-enter" style={{ paddingTop: 'calc(var(--nav-height) + 40px)' }}>
      <section className="section" style={{ paddingTop: 40 }}>
        <div className="container">
          <ScrollReveal className="text-center" style={{ marginBottom: 40 }}>
            <h1 className="section-title">Ürünler</h1>
            <p className="section-subtitle" style={{ margin: '0 auto' }}>
              Hazır ve özel sistemlerimizi detaylıca inceleyin.
            </p>
          </ScrollReveal>

          <ScrollReveal>
            <div style={{
              display: 'flex', gap: 8, justifyContent: 'center', flexWrap: 'wrap',
              marginBottom: 48,
            }}>
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={activeCategory === cat.id ? 'btn btn-primary' : 'btn btn-secondary'}
                  style={{ padding: '10px 20px', fontSize: '0.9rem' }}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </ScrollReveal>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
            {filtered.map((product, i) => {
              const isExpanded = expanded === product.id
              return (
                <ScrollReveal key={product.id} delay={((i % 3) + 1) as 1|2|3}>
                  <div
                    className="card"
                    onClick={() => setExpanded(isExpanded ? null : product.id)}
                    style={{ cursor: 'pointer', padding: 0, overflow: 'hidden' }}
                  >
                    <div style={{ padding: '28px 32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 24 }} className="product-header">
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap', marginBottom: 8 }}>
                          <h3 style={{ fontSize: '1.15rem', fontWeight: 700 }}>{product.name}</h3>
                          <span className={`tag ${statusLabels[product.status].className}`}>{statusLabels[product.status].label}</span>
                          <span className="tag tag-muted">{categoryLabels[product.category]}</span>
                        </div>
                        <p style={{ color: 'var(--text-secondary)', lineHeight: 1.6, fontSize: '0.95rem' }}>{product.description}</p>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 16, flexShrink: 0 }}>
                        <span className="gradient-text" style={{ fontWeight: 800, fontSize: '1.15rem', whiteSpace: 'nowrap' }}>{product.price}</span>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" strokeWidth="2"
                          style={{ transform: isExpanded ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform var(--transition)' }}>
                          <polyline points="6 9 12 15 18 9"/>
                        </svg>
                      </div>
                    </div>
                    {isExpanded && (
                      <div style={{
                        borderTop: '1px solid var(--border)',
                        padding: '24px 32px',
                        background: 'var(--bg-alt)',
                      }}>
                        <p style={{ color: 'var(--text-secondary)', lineHeight: 1.8, marginBottom: 20, fontSize: '0.95rem' }}>
                          {product.longDescription}
                        </p>
                        <div style={{ marginBottom: 20 }}>
                          <h4 style={{ fontWeight: 700, marginBottom: 12, fontSize: '0.95rem' }}>Özellikler</h4>
                          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                            {product.features.map(f => (
                              <span key={f} className="tag tag-primary" style={{ fontSize: '0.85rem', padding: '6px 14px' }}>{f}</span>
                            ))}
                          </div>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
                          {product.support && (
                            <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: 'var(--secondary)', fontSize: '0.9rem', fontWeight: 600 }}>
                              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                              Destek var
                            </span>
                          )}
                          {product.status !== 'coming-soon' && (
                            <DiscordCTA title="Satın Al / İncele" />
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </ScrollReveal>
              )
            })}
          </div>

          <style>{`
            @media (max-width: 768px) {
              .product-header { flex-direction: column; align-items: stretch !important; }
            }
          `}</style>
        </div>
      </section>
    </div>
  )
}
