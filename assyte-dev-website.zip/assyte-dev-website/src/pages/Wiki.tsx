import { useState } from 'react'
import ScrollReveal from '../components/ScrollReveal'
import { wikiArticles, wikiCategories } from '../data/wiki'

export default function Wiki() {
  const [activeCategory, setActiveCategory] = useState<string>(wikiCategories[0])
  const [activeArticle, setActiveArticle] = useState(wikiArticles[0].id)

  const filteredArticles = wikiArticles.filter(a => a.category === activeCategory)
  const currentArticle = wikiArticles.find(a => a.id === activeArticle) || wikiArticles[0]

  return (
    <div className="page-enter" style={{ paddingTop: 'calc(var(--nav-height) + 40px)' }}>
      <section className="section" style={{ paddingTop: 40 }}>
        <div className="container">
          <ScrollReveal style={{ marginBottom: 48 }}>
            <h1 className="section-title">Wiki</h1>
            <p className="section-subtitle">
              Kurulum, yapılandırma ve kullanım rehberleri.
            </p>
          </ScrollReveal>

          <div style={{ display: 'flex', gap: 32, alignItems: 'flex-start' }} className="wiki-layout">
            {/* Sidebar */}
            <aside className="wiki-sidebar" style={{
              flexShrink: 0,
              width: 280,
              position: 'sticky',
              top: 'calc(var(--nav-height) + 40px)',
              maxHeight: 'calc(100vh - var(--nav-height) - 80px)',
              overflowY: 'auto',
            }}>
              <nav style={{
                background: 'var(--bg-card)',
                border: '1px solid var(--border)',
                borderRadius: 'var(--radius-lg)',
                padding: 16,
              }}>
                {wikiCategories.map(cat => (
                  <div key={cat} style={{ marginBottom: 8 }}>
                    <button
                      onClick={() => {
                        setActiveCategory(cat)
                        const article = wikiArticles.find(a => a.category === cat)
                        if (article) setActiveArticle(article.id)
                      }}
                      style={{
                        width: '100%',
                        textAlign: 'left',
                        padding: '10px 14px',
                        borderRadius: 'var(--radius-sm)',
                        fontWeight: activeCategory === cat ? 700 : 500,
                        color: activeCategory === cat ? 'var(--primary)' : 'var(--text-secondary)',
                        background: activeCategory === cat ? 'rgba(14,165,233,0.08)' : 'transparent',
                        fontSize: '0.9rem',
                        transition: 'all var(--transition)',
                      }}
                    >
                      {cat}
                    </button>
                    {activeCategory === cat && (
                      <div style={{ paddingLeft: 12, marginTop: 4, display: 'flex', flexDirection: 'column', gap: 2 }}>
                        {filteredArticles.map(a => (
                          <button
                            key={a.id}
                            onClick={() => setActiveArticle(a.id)}
                            style={{
                              width: '100%',
                              textAlign: 'left',
                              padding: '8px 14px',
                              borderRadius: 'var(--radius-sm)',
                              fontSize: '0.85rem',
                              fontWeight: activeArticle === a.id ? 600 : 400,
                              color: activeArticle === a.id ? 'var(--text)' : 'var(--text-muted)',
                              background: activeArticle === a.id ? 'var(--bg-alt)' : 'transparent',
                              transition: 'all var(--transition)',
                            }}
                          >
                            {a.title}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </nav>
            </aside>

            {/* Content */}
            <main className="wiki-content" style={{ flex: 1, minWidth: 0 }}>
              <ScrollReveal key={currentArticle.id}>
                <article style={{
                  background: 'var(--bg-card)',
                  border: '1px solid var(--border)',
                  borderRadius: 'var(--radius-lg)',
                  padding: '40px',
                }} className="wiki-article">
                  <h2 style={{ fontSize: '1.75rem', fontWeight: 800, marginBottom: 24 }}>
                    {currentArticle.title}
                  </h2>
                  <div className="wiki-body">
                    {currentArticle.content.split('\n').map((line, i) => {
                      if (line.startsWith('## ')) {
                        return <h3 key={i} style={{ fontSize: '1.25rem', fontWeight: 700, marginTop: 28, marginBottom: 12, color: 'var(--text)' }}>{line.replace('## ', '')}</h3>
                      }
                      if (line.startsWith('- ')) {
                        return <li key={i} style={{ color: 'var(--text-secondary)', lineHeight: 1.8, marginLeft: 20 }}>{line.replace('- ', '')}</li>
                      }
                      if (line.startsWith('```') || line.startsWith('```yaml')) {
                        return null
                      }
                      if (line.trim() === '') return <br key={i} />
                      if (line.startsWith('  ')) {
                        return <pre key={i} style={{
                          background: 'var(--bg-alt)',
                          border: '1px solid var(--border)',
                          borderRadius: 'var(--radius-sm)',
                          padding: '12px 16px',
                          margin: '8px 0',
                          fontSize: '0.85rem',
                          fontFamily: 'var(--font-mono)',
                          color: 'var(--text)',
                          overflowX: 'auto',
                          whiteSpace: 'pre-wrap',
                          lineHeight: 1.5,
                        }}>{line}</pre>
                      }
                      // Check for inline code or bold
                      const processed = line
                        .replace(/\*\*(.*?)\*\*/g, '<strong style="color:var(--text)">$1</strong>')
                        .replace(/`(.*?)`/g, '<code style="background:var(--bg-alt);padding:2px 6px;border-radius:4px;font-size:0.85em;border:1px solid var(--border)">$1</code>')
                      return <p key={i} style={{ color: 'var(--text-secondary)', lineHeight: 1.8, marginBottom: 8 }} dangerouslySetInnerHTML={{ __html: processed }} />
                    })}
                  </div>
                </article>
              </ScrollReveal>
            </main>
          </div>

          <style>{`
            @media (max-width: 768px) {
              .wiki-layout { flex-direction: column; }
              .wiki-sidebar {
                width: 100% !important;
                position: static !important;
                max-height: none !important;
                margin-bottom: 24px;
              }
              .wiki-article { padding: 24px !important; }
              .wiki-article h2 { font-size: 1.4rem !important; }
            }
          `}</style>
        </div>
      </section>
    </div>
  )
}
