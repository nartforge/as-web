import ScrollReveal from '../components/ScrollReveal'
import ProductCard from '../components/ProductCard'
import DiscordCTA from '../components/DiscordCTA'
import { storeProducts } from '../data/products'

export default function Store() {
  return (
    <div className="page-enter" style={{ paddingTop: 'calc(var(--nav-height) + 40px)' }}>
      <section className="section" style={{ paddingTop: 40 }}>
        <div className="container">
          <ScrollReveal className="text-center" style={{ marginBottom: 60 }}>
            <h1 className="section-title">Mağaza</h1>
            <p className="section-subtitle" style={{ margin: '0 auto' }}>
              Premium yazılım çözümlerimizi inceleyin. Tüm satın alma işlemleri Discord üzerinden gerçekleşir.
            </p>
          </ScrollReveal>

          <div className="grid-3">
            {storeProducts.map((product, i) => (
              <ScrollReveal key={product.id} delay={((i % 3) + 1) as 1|2|3}>
                <ProductCard product={product} />
              </ScrollReveal>
            ))}
          </div>

          <ScrollReveal className="text-center" style={{ marginTop: 60 }}>
            <div className="card" style={{ maxWidth: 500, margin: '0 auto', textAlign: 'center', padding: '40px 32px' }}>
              <h3 style={{ fontWeight: 700, marginBottom: 12, fontSize: '1.2rem' }}>Özel bir çözüm mü arıyorsunuz?</h3>
              <p style={{ color: 'var(--text-secondary)', marginBottom: 24, lineHeight: 1.7 }}>
                Size özel yazılım, bot veya sistem geliştirmemizi isterseniz Discord üzerinden bizimle iletişime geçin.
              </p>
              <DiscordCTA title="Teklif Al" />
            </div>
          </ScrollReveal>
        </div>
      </section>
    </div>
  )
}
