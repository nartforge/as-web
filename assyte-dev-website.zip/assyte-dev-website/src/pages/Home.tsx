import { Link } from 'react-router-dom'
import DiscordCTA from '../components/DiscordCTA'
import ScrollReveal from '../components/ScrollReveal'
import { products } from '../data/products'

const features = [
  {
    title: 'Discord Botları',
    desc: 'Moderasyon, eğlence, yardım veya özel senaryolar için Discord bot altyapıları.',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      </svg>
    ),
  },
  {
    title: 'Minecraft Sistemleri',
    desc: 'Premium pluginler, oyun sistemleri ve sunucu altyapı çözümleri.',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>
      </svg>
    ),
  },
  {
    title: 'Web Çözümleri',
    desc: 'Modern, responsive ve SEO uyumlu web sitesi ve panel geliştirme.',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
      </svg>
    ),
  },
  {
    title: 'Özel Yazılım',
    desc: 'İhtiyacınıza özel, sıfırdan geliştirilmiş yazılım altyapıları.',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>
      </svg>
    ),
  },
]

const stats = [
  { number: '15+', label: 'Ürün' },
  { number: '500+', label: 'Mutlu Müşteri' },
  { number: '7/24', label: 'Destek' },
  { number: '%100', label: 'Müşteri Memnuniyeti' },
]

const whyUs = [
  {
    title: 'Premium Kalite',
    desc: 'Tüm ürünlerimiz en yüksek kod standartlarında, temiz ve optimize şekilde geliştirilir.',
  },
  {
    title: 'Sürekli Güncelleme',
    desc: 'Ürünlerimiz düzenli olarak güncellenir, yeni özellikler eklenir ve hatalar giderilir.',
  },
  {
    title: 'Hızlı Destek',
    desc: 'Discord sunucumuz üzerinden 7/24 hızlı ve profesyonel destek alabilirsiniz.',
  },
  {
    title: 'Özelleştirme',
    desc: 'İhtiyaçlarınıza göre tamamen özelleştirilmiş çözümler sunuyoruz.',
  },
]

export default function Home() {
  return (
    <div className="page-enter">
      {/* Hero / Discord CTA */}
      <section style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
        paddingTop: 'var(--nav-height)',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', inset: 0,
          background: 'radial-gradient(ellipse at 50% 0%, rgba(14,165,233,0.08) 0%, transparent 60%)',
          pointerEvents: 'none',
        }} />
        <div className="container" style={{ position: 'relative', zIndex: 1 }}>
          <ScrollReveal>
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: 12,
              background: 'var(--bg-card)', border: '1px solid var(--border)',
              padding: '8px 20px', borderRadius: 'var(--radius-full)',
              marginBottom: 32,
            }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#22C55E', display: 'block' }} />
              <span style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>Topluluğa katıl, öne çık</span>
            </div>
          </ScrollReveal>

          <ScrollReveal delay={1}>
            <h1 style={{
              fontSize: 'clamp(2.5rem, 6vw, 4.5rem)',
              fontWeight: 900,
              lineHeight: 1.1,
              marginBottom: 16,
              letterSpacing: '-1px',
            }}>
              Premium Yazılım<br />
              <span className="gradient-text">Çözümleri</span>
            </h1>
          </ScrollReveal>

          <ScrollReveal delay={2}>
            <p style={{
              fontSize: 'clamp(1rem, 2vw, 1.25rem)',
              color: 'var(--text-secondary)',
              maxWidth: 560,
              margin: '0 auto 24px',
              lineHeight: 1.7,
            }}>
              Duyurular, ürün güncellemeleri ve destek için Discord sunucumuza katılın!
            </p>
          </ScrollReveal>

          <ScrollReveal delay={3}>
            <div style={{ display: 'flex', gap: 16, justifyContent: 'center', flexWrap: 'wrap' }}>
              <DiscordCTA variant="hero" title="Discord'a Katıl" />
              <Link to="/urunler" className="btn btn-secondary btn-lg">
                Ürünleri İncele
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
              </Link>
            </div>
          </ScrollReveal>

          <div style={{ marginTop: 80, display: 'flex', justifyContent: 'center' }} className="float">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="section" style={{ paddingTop: 0, paddingBottom: 80 }}>
        <div className="container">
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(4, 1fr)',
            gap: 24,
            background: 'var(--bg-card)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius-xl)',
            padding: '40px 24px',
          }} className="stats-grid">
            {stats.map((s, i) => (
              <ScrollReveal key={s.label} delay={(i + 1) as 1|2|3|4}>
                <div style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: '2.5rem', fontWeight: 900, background: 'var(--gradient-primary)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', marginBottom: 4 }}>{s.number}</div>
                  <div style={{ fontSize: '0.9rem', color: 'var(--text-secondary)' }}>{s.label}</div>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
        <style>{`@media (max-width: 640px) { .stats-grid { grid-template-columns: repeat(2, 1fr) !important; gap: 16px !important; } }`}</style>
      </section>

      {/* What is Assyte Dev */}
      <section className="section" style={{ background: 'var(--bg-alt)', paddingTop: 80, paddingBottom: 80 }}>
        <div className="container">
          <div className="grid-2" style={{ alignItems: 'center', gap: 60 }}>
            <ScrollReveal>
              <h2 className="section-title">Assyte Dev Nedir?</h2>
              <p style={{ color: 'var(--text-secondary)', lineHeight: 1.8, marginBottom: 20, fontSize: '1.05rem' }}>
                Assyte Dev, kullanıcı isteklerine göre <strong style={{ color: 'var(--text)' }}>Discord botları, Minecraft sunucu sistemleri, pluginler, web çözümleri ve özel yazılım altyapıları</strong> geliştiren bir ekip/markadır.
              </p>
              <p style={{ color: 'var(--text-secondary)', lineHeight: 1.8, fontSize: '1.05rem' }}>
                Amacımız, oyun toplulukları ve dijital işletmeler için profesyonel, güvenilir ve yenilikçi yazılım çözümleri sunmaktır.
              </p>
            </ScrollReveal>
            <ScrollReveal delay={2}>
              <div style={{
                background: 'var(--bg-card)',
                border: '1px solid var(--border)',
                borderRadius: 'var(--radius-xl)',
                padding: 40,
                position: 'relative',
                overflow: 'hidden',
              }}>
                <div style={{
                  position: 'absolute', top: '-50%', right: '-50%', width: '100%', height: '100%',
                  background: 'radial-gradient(circle, rgba(14,165,233,0.06) 0%, transparent 70%)',
                }} />
                <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 20, position: 'relative' }}>
                  {[
                    'Mağaza üzerinden ürünler incelenebilir.',
                    'Ürünler sayfasında hazır ve özel sistemler listelenebilir.',
                    'Wiki sayfasında kurulum ve kullanım rehberleri bulunur.',
                    'Destek sayfasından Discord ve iletişim kanallarıyla yardım alınabilir.',
                  ].map((text, i) => (
                    <li key={i} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                      <span style={{
                        minWidth: 24, height: 24, borderRadius: '50%',
                        background: 'var(--gradient-primary)', color: '#fff',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        fontSize: '0.8rem', fontWeight: 700, flexShrink: 0, marginTop: 2,
                      }}>
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>
                      </span>
                      <span style={{ color: 'var(--text-secondary)', lineHeight: 1.6 }}>{text}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="section">
        <div className="container">
          <ScrollReveal className="text-center" style={{ marginBottom: 60 }}>
            <h2 className="section-title">Neler Sunuyoruz?</h2>
            <p className="section-subtitle" style={{ margin: '0 auto' }}>
              Oyun toplulukları ve dijital işletmeler için kapsamlı çözümler.
            </p>
          </ScrollReveal>
          <div className="grid-4">
            {features.map((f, i) => (
              <ScrollReveal key={f.title} delay={(i + 1) as 1|2|3|4}>
                <div className="card" style={{ textAlign: 'center', padding: '40px 24px' }}>
                  <div style={{
                    width: 56, height: 56, borderRadius: 'var(--radius-md)',
                    background: 'var(--gradient-primary)', color: '#fff',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    margin: '0 auto 20px',
                  }}>
                    {f.icon}
                  </div>
                  <h3 style={{ fontWeight: 700, marginBottom: 8, fontSize: '1.1rem' }}>{f.title}</h3>
                  <p style={{ color: 'var(--text-secondary)', lineHeight: 1.7, fontSize: '0.9rem' }}>{f.desc}</p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="section" style={{ background: 'var(--bg-alt)' }}>
        <div className="container">
          <ScrollReveal className="text-center" style={{ marginBottom: 60 }}>
            <h2 className="section-title">Öne Çıkan Sistemler</h2>
            <p className="section-subtitle" style={{ margin: '0 auto' }}>
              En çok tercih edilen ürünlerimiz.
            </p>
          </ScrollReveal>
          <div className="grid-3">
            {products.slice(0, 3).map((product, i) => (
              <ScrollReveal key={product.id} delay={(i + 1) as 1|2|3}>
                <Link to="/magaza" style={{ display: 'block' }}>
                  <div className="card card-gradient" style={{ height: '100%' }}>
                    <div style={{ marginBottom: 16 }}>
                      <span className={`tag ${product.status === 'active' ? 'tag-success' : product.status === 'beta' ? 'tag-warning' : 'tag-muted'}`}>
                        {product.status === 'active' ? 'Aktif' : product.status === 'beta' ? 'Beta' : 'Yakında'}
                      </span>
                    </div>
                    <h3 style={{ fontWeight: 700, marginBottom: 8, fontSize: '1.15rem' }}>{product.name}</h3>
                    <p style={{ color: 'var(--text-secondary)', lineHeight: 1.7, fontSize: '0.9rem', marginBottom: 16 }}>{product.description}</p>
                    <span className="gradient-text" style={{ fontWeight: 800, fontSize: '1.1rem' }}>{product.price}</span>
                  </div>
                </Link>
              </ScrollReveal>
            ))}
          </div>
          <ScrollReveal className="text-center" style={{ marginTop: 40 }}>
            <Link to="/magaza" className="btn btn-primary">
              Tüm Ürünleri Gör
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
            </Link>
          </ScrollReveal>
        </div>
      </section>

      {/* Why Us */}
      <section className="section">
        <div className="container">
          <ScrollReveal className="text-center" style={{ marginBottom: 60 }}>
            <h2 className="section-title">Neden Assyte Dev?</h2>
            <p className="section-subtitle" style={{ margin: '0 auto' }}>
              Bizi tercih etmeniz için 4 neden.
            </p>
          </ScrollReveal>
          <div className="grid-4">
            {whyUs.map((w, i) => (
              <ScrollReveal key={w.title} delay={(i + 1) as 1|2|3|4}>
                <div className="card" style={{ padding: '32px 24px' }}>
                  <div style={{
                    width: 40, height: 4, borderRadius: 2,
                    background: 'var(--gradient-primary)', marginBottom: 20,
                  }} />
                  <h3 style={{ fontWeight: 700, marginBottom: 8, fontSize: '1.05rem' }}>{w.title}</h3>
                  <p style={{ color: 'var(--text-secondary)', lineHeight: 1.7, fontSize: '0.9rem' }}>{w.desc}</p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="section" style={{ background: 'var(--bg-alt)', textAlign: 'center' }}>
        <div className="container">
          <ScrollReveal>
            <div style={{
              background: 'var(--bg-card)',
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius-xl)',
              padding: '60px 40px',
              position: 'relative',
              overflow: 'hidden',
            }}>
              <div style={{
                position: 'absolute', inset: 0,
                background: 'radial-gradient(ellipse at center, rgba(14,165,233,0.05) 0%, transparent 70%)',
              }} />
              <div style={{ position: 'relative' }}>
                <h2 className="section-title" style={{ fontSize: '2rem' }}>Hazır mısın?</h2>
                <p style={{ color: 'var(--text-secondary)', marginBottom: 32, fontSize: '1.1rem' }}>
                  Discord sunucumuza katıl, topluluğun bir parçası ol.
                </p>
                <DiscordCTA variant="hero" title="Discord'a Katıl" />
              </div>
            </div>
          </ScrollReveal>
        </div>
      </section>
    </div>
  )
}
