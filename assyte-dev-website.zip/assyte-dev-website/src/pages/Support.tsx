import { useState } from 'react'
import ScrollReveal from '../components/ScrollReveal'
import DiscordCTA from '../components/DiscordCTA'

const supportCards = [
  {
    title: 'Genel Destek',
    desc: 'Ürünlerimiz hakkında genel sorularınız için bize ulaşın.',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/>
      </svg>
    ),
  },
  {
    title: 'Ürün Kurulumu',
    desc: 'Satın aldığınız ürünlerin kurulumu ve yapılandırması için yardım.',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>
      </svg>
    ),
  },
  {
    title: 'Özel Sipariş',
    desc: 'Size özel yazılım, bot veya sistem geliştirme talepleri.',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>
      </svg>
    ),
  },
  {
    title: 'Hata Bildirimi',
    desc: 'Karşılaştığınız hataları ve sorunları bize bildirin.',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
      </svg>
    ),
  },
]

export default function Support() {
  const [submitted, setSubmitted] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name || !form.email || !form.subject || !form.message) return
    setSubmitted(true)
  }

  return (
    <div className="page-enter" style={{ paddingTop: 'calc(var(--nav-height) + 40px)' }}>
      <section className="section" style={{ paddingTop: 40 }}>
        <div className="container">
          <ScrollReveal className="text-center" style={{ marginBottom: 60 }}>
            <h1 className="section-title">Destek</h1>
            <p className="section-subtitle" style={{ margin: '0 auto' }}>
              Sorularınız mı var? Size yardımcı olmak için buradayız.
            </p>
          </ScrollReveal>

          {/* Support Cards */}
          <div className="grid-4" style={{ marginBottom: 80 }}>
            {supportCards.map((card, i) => (
              <ScrollReveal key={card.title} delay={(i + 1) as 1|2|3|4}>
                <div className="card" style={{ textAlign: 'center', padding: '36px 24px' }}>
                  <div style={{
                    width: 48, height: 48, borderRadius: 'var(--radius-md)',
                    background: 'var(--gradient-primary)', color: '#fff',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    margin: '0 auto 16px',
                  }}>
                    {card.icon}
                  </div>
                  <h3 style={{ fontWeight: 700, marginBottom: 8, fontSize: '1rem' }}>{card.title}</h3>
                  <p style={{ color: 'var(--text-secondary)', lineHeight: 1.7, fontSize: '0.9rem', marginBottom: 16 }}>
                    {card.desc}
                  </p>
                  <DiscordCTA variant="inline" title="İletişime Geç" />
                </div>
              </ScrollReveal>
            ))}
          </div>

          {/* Discord CTA */}
          <ScrollReveal style={{ marginBottom: 80 }}>
            <div className="card" style={{
              textAlign: 'center', padding: '48px 32px',
              background: 'linear-gradient(135deg, rgba(88,101,242,0.05), rgba(88,101,242,0.02))',
              border: '1px solid rgba(88,101,242,0.2)',
            }}>
              <h2 style={{ fontSize: '1.5rem', fontWeight: 800, marginBottom: 12 }}>
                En Hızlı Destek Discord'da
              </h2>
              <p style={{ color: 'var(--text-secondary)', marginBottom: 28, maxWidth: 500, margin: '0 auto 28px', lineHeight: 1.7 }}>
                Anında yanıt almak ve topluluğumuza katılmak için Discord sunucumuza bekliyoruz.
              </p>
              <DiscordCTA variant="hero" title="Discord'a Katıl" />
            </div>
          </ScrollReveal>

          {/* Contact Form */}
          <ScrollReveal>
            <div className="card" style={{ maxWidth: 600, margin: '0 auto', padding: '40px 32px' }}>
              <h2 style={{ fontSize: '1.3rem', fontWeight: 700, marginBottom: 8 }}>İletişim Formu</h2>
              <p style={{ color: 'var(--text-secondary)', marginBottom: 28, fontSize: '0.9rem' }}>
                Formu doldurun, size en kısa sürede dönüş yapalım.
              </p>

              {submitted ? (
                <div style={{ textAlign: 'center', padding: '40px 20px' }}>
                  <div style={{
                    width: 64, height: 64, borderRadius: '50%',
                    background: 'var(--gradient-primary)', color: '#fff',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    margin: '0 auto 20px', fontSize: '1.5rem',
                  }}>
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                  </div>
                  <h3 style={{ fontWeight: 700, marginBottom: 8 }}>Teşekkürler!</h3>
                  <p style={{ color: 'var(--text-secondary)', marginBottom: 20, lineHeight: 1.7 }}>
                    Destek talebiniz için Discord sunucumuza yönlendiriliyorsunuz.
                  </p>
                  <DiscordCTA title="Discord'a Git" />
                </div>
              ) : (
                <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                    <div>
                      <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: 6, color: 'var(--text-secondary)' }}>
                        Adınız
                      </label>
                      <input
                        required
                        value={form.name}
                        onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                        placeholder="Adınız"
                        style={{
                          width: '100%', padding: '12px 16px',
                          background: 'var(--bg-alt)', border: '1px solid var(--border)',
                          borderRadius: 'var(--radius-sm)', color: 'var(--text)',
                          fontSize: '0.95rem', outline: 'none',
                          transition: 'border-color var(--transition)',
                        }}
                        onFocus={e => e.target.style.borderColor = 'var(--primary)'}
                        onBlur={e => e.target.style.borderColor = 'var(--border)'}
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: 6, color: 'var(--text-secondary)' }}>
                        E-posta
                      </label>
                      <input
                        required
                        type="email"
                        value={form.email}
                        onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                        placeholder="ornek@email.com"
                        style={{
                          width: '100%', padding: '12px 16px',
                          background: 'var(--bg-alt)', border: '1px solid var(--border)',
                          borderRadius: 'var(--radius-sm)', color: 'var(--text)',
                          fontSize: '0.95rem', outline: 'none',
                          transition: 'border-color var(--transition)',
                        }}
                        onFocus={e => e.target.style.borderColor = 'var(--primary)'}
                        onBlur={e => e.target.style.borderColor = 'var(--border)'}
                      />
                    </div>
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: 6, color: 'var(--text-secondary)' }}>
                      Konu
                    </label>
                    <input
                      required
                      value={form.subject}
                      onChange={e => setForm(f => ({ ...f, subject: e.target.value }))}
                      placeholder="Destek konusu"
                      style={{
                        width: '100%', padding: '12px 16px',
                        background: 'var(--bg-alt)', border: '1px solid var(--border)',
                        borderRadius: 'var(--radius-sm)', color: 'var(--text)',
                        fontSize: '0.95rem', outline: 'none',
                        transition: 'border-color var(--transition)',
                      }}
                      onFocus={e => e.target.style.borderColor = 'var(--primary)'}
                      onBlur={e => e.target.style.borderColor = 'var(--border)'}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: 6, color: 'var(--text-secondary)' }}>
                      Mesajınız
                    </label>
                    <textarea
                      required
                      value={form.message}
                      onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                      placeholder="Detaylı olarak açıklayın..."
                      rows={5}
                      style={{
                        width: '100%', padding: '12px 16px', resize: 'vertical',
                        background: 'var(--bg-alt)', border: '1px solid var(--border)',
                        borderRadius: 'var(--radius-sm)', color: 'var(--text)',
                        fontSize: '0.95rem', outline: 'none', fontFamily: 'inherit',
                        transition: 'border-color var(--transition)',
                      }}
                      onFocus={e => e.target.style.borderColor = 'var(--primary)'}
                      onBlur={e => e.target.style.borderColor = 'var(--border)'}
                    />
                  </div>
                  <button type="submit" className="btn btn-primary" style={{ alignSelf: 'flex-start', marginTop: 8 }}>
                    Gönder
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                  </button>
                </form>
              )}
            </div>
          </ScrollReveal>
        </div>
      </section>
    </div>
  )
}
