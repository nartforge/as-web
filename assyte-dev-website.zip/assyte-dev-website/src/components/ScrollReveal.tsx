import { type ReactNode, type CSSProperties } from 'react'
import { useScrollAnimation } from '../hooks/useScrollAnimation'

interface Props {
  children: ReactNode
  delay?: 1 | 2 | 3 | 4
  className?: string
  style?: CSSProperties
}

export default function ScrollReveal({ children, delay, className = '', style }: Props) {
  const { ref, visible } = useScrollAnimation()

  return (
    <div
      ref={ref}
      className={`reveal ${visible ? 'visible' : ''} ${delay ? `reveal-delay-${delay}` : ''} ${className}`}
      style={style}
    >
      {children}
    </div>
  )
}
