import { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useTheme } from '../context/ThemeContext'
import DiscordCTA from './DiscordCTA'

const navLinks = [
  { to: '/', label: 'Ana Sayfa' },
  { to: '/magaza', label: 'Mağaza' },
  { to: '/urunler', label: 'Ürünler' },
  { to: '/wiki', label: 'Wiki' },
  { to: '/destek', label: 'Destek' },
]

export default function Header() {
  const { theme, toggleTheme } = useTheme()
  const location = useLocation()
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    setMenuOpen(false)
  }, [location])

  return (
    <header
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 1000,
        height: 'var(--nav-height)',
        background: scrolled ? 'var(--bg)' : 'transparent',
        borderBottom: scrolled ? '1px solid var(--border)' : '1px solid transparent',
        transition: 'all var(--transition)',
        backdropFilter: scrolled ? 'blur(12px)' : 'none',
      }}
    >
      <nav className="container" style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 10, fontWeight: 800, fontSize: '1.25rem', letterSpacing: '-0.5px' }}>
          <svg width="32" height="32" viewBox="0 0 64 64" fill="none">
            <rect width="64" height="64" rx="14" fill="url(#logo-grad)"/>
            <text x="32" y="44" fontFamily="Arial,sans-serif" fontSize="32" fontWeight="bold" fill="#fff" textAnchor="middle">A</text>
            <defs>
              <linearGradient id="logo-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#0EA5E9"/>
                <stop offset="100%" stopColor="#14B8A6"/>
              </linearGradient>
            </defs>
          </svg>
          Assyte Dev
        </Link>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div className={`nav-desktop ${menuOpen ? 'open' : ''}`} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            {navLinks.map(link => (
              <Link
                key={link.to}
                to={link.to}
                className={`nav-link ${location.pathname === link.to ? 'active' : ''}`}
                style={{ padding: '8px 16px' }}
              >
                {link.label}
              </Link>
            ))}
          </div>

          <button
            onClick={toggleTheme}
            style={{
              width: 40, height: 40, display: 'flex', alignItems: 'center', justifyContent: 'center',
              borderRadius: 'var(--radius-md)', border: '1px solid var(--border)',
              background: 'var(--bg-card)', color: 'var(--text)', fontSize: '1.1rem',
              transition: 'all var(--transition)', marginLeft: 8,
            }}
            aria-label="Tema değiştir"
          >
            {theme === 'dark' ? '☀️' : '🌙'}
          </button>

          <DiscordCTA title="" variant="inline" />

          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="mobile-menu-btn"
            style={{
              width: 40, height: 40, display: 'none', alignItems: 'center', justifyContent: 'center',
              borderRadius: 'var(--radius-md)', border: '1px solid var(--border)',
              background: 'var(--bg-card)', color: 'var(--text)', fontSize: '1.3rem',
            }}
            aria-label="Menü"
          >
            {menuOpen ? '✕' : '☰'}
          </button>
        </div>
      </nav>

      <style>{`
        @media (max-width: 768px) {
          .mobile-menu-btn { display: flex !important; }
          .nav-desktop {
            position: fixed;
            top: var(--nav-height);
            left: 0;
            right: 0;
            background: var(--bg);
            border-bottom: 1px solid var(--border);
            flex-direction: column !important;
            padding: 16px;
            transform: translateY(-100%);
            opacity: 0;
            pointer-events: none;
            transition: all var(--transition);
          }
          .nav-desktop.open {
            transform: translateY(0);
            opacity: 1;
            pointer-events: all;
          }
          .nav-desktop .nav-link {
            padding: 12px 16px !important;
            width: 100%;
          }
          .btn-discord span { display: none; }
        }
      `}</style>
    </header>
  )
}
