import { Link } from 'react-router-dom'

const footerLinks = [
  { to: '/magaza', label: 'Mağaza' },
  { to: '/urunler', label: 'Ürünler' },
  { to: '/wiki', label: 'Wiki' },
  { to: '/destek', label: 'Destek' },
]

export default function Footer() {
  return (
    <footer style={{
      borderTop: '1px solid var(--border)',
      background: 'var(--bg-alt)',
      padding: '48px 0 24px',
      marginTop: 'auto',
    }}>
      <div className="container">
        <div style={{
          display: 'grid',
          gridTemplateColumns: '2fr 1fr 1fr',
          gap: 48,
          marginBottom: 40,
        }} className="footer-grid">
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontWeight: 800, fontSize: '1.25rem', marginBottom: 12 }}>
              <svg width="28" height="28" viewBox="0 0 64 64" fill="none">
                <rect width="64" height="64" rx="14" fill="url(#flogo)"/>
                <text x="32" y="44" fontFamily="Arial,sans-serif" fontSize="32" fontWeight="bold" fill="#fff" textAnchor="middle">A</text>
                <defs>
                  <linearGradient id="flogo" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#0EA5E9"/>
                    <stop offset="100%" stopColor="#14B8A6"/>
                  </linearGradient>
                </defs>
              </svg>
              Assyte Dev
            </div>
            <p style={{ color: 'var(--text-secondary)', lineHeight: 1.7, maxWidth: 360, fontSize: '0.9rem' }}>
              Discord botları, Minecraft sunucu sistemleri, pluginler, web çözümleri ve özel yazılım altyapıları geliştiren ekip.
            </p>
          </div>

          <div>
            <h4 style={{ fontWeight: 700, marginBottom: 16, fontSize: '0.95rem' }}>Sayfalar</h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {footerLinks.map(link => (
                <Link key={link.to} to={link.to} style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', transition: 'color var(--transition)' }}
                  className="footer-link">
                  {link.label}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h4 style={{ fontWeight: 700, marginBottom: 16, fontSize: '0.95rem' }}>Bağlantılar</h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <a href="https://discord.gg/assytedev" target="_blank" rel="noopener noreferrer"
                style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', transition: 'color var(--transition)' }}
                className="footer-link">
                Discord
              </a>
            </div>
          </div>
        </div>

        <div style={{
          borderTop: '1px solid var(--border)',
          paddingTop: 20,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          fontSize: '0.85rem',
          color: 'var(--text-muted)',
        }} className="footer-bottom">
          <span>© {new Date().getFullYear()} Assyte Dev. Tüm hakları saklıdır.</span>
        </div>
      </div>

      <style>{`
        .footer-link:hover { color: var(--primary) !important; }
        @media (max-width: 768px) {
          .footer-grid { grid-template-columns: 1fr !important; gap: 32px !important; }
          .footer-bottom { flex-direction: column; gap: 8px; text-align: center; }
        }
      `}</style>
    </footer>
  )
}
