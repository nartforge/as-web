import { type Product } from '../data/products'
import DiscordCTA from './DiscordCTA'

interface Props {
  product: Product
  featured?: boolean
}

const statusLabels: Record<string, { label: string; className: string }> = {
  'active': { label: 'Aktif', className: 'tag-success' },
  'beta': { label: 'Beta', className: 'tag-warning' },
  'coming-soon': { label: 'Çok Yakında', className: 'tag-muted' },
}

export default function ProductCard({ product, featured }: Props) {
  const status = statusLabels[product.status]

  return (
    <div className={`card card-gradient ${featured ? 'featured' : ''}`}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
        <h3 style={{ fontSize: '1.25rem', fontWeight: 700 }}>{product.name}</h3>
        <span className={`tag ${status.className}`}>{status.label}</span>
      </div>
      <p style={{ color: 'var(--text-secondary)', marginBottom: 16, lineHeight: 1.7, fontSize: '0.95rem' }}>
        {product.description}
      </p>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 20 }}>
        {product.features.slice(0, 3).map(f => (
          <span key={f} className="tag tag-primary">{f}</span>
        ))}
        {product.features.length > 3 && (
          <span className="tag tag-muted">+{product.features.length - 3}</span>
        )}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 'auto', paddingTop: 16, borderTop: '1px solid var(--border)' }}>
        <span style={{ fontSize: '1.25rem', fontWeight: 800, background: 'var(--gradient-primary)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
          {product.price}
        </span>
        {product.status !== 'coming-soon' ? (
          <DiscordCTA variant="card" title="İncele" />
        ) : (
          <span className="tag tag-muted">Yakında</span>
        )}
      </div>
      {featured && (
        <div style={{
          position: 'absolute', top: -1, right: 24, padding: '4px 16px',
          background: 'var(--gradient-primary)', color: '#fff', fontSize: '0.75rem',
          fontWeight: 700, borderRadius: '0 0 8px 8px', letterSpacing: 1, textTransform: 'uppercase'
        }}>
          Öne Çıkan
        </div>
      )}
    </div>
  )
}
