export interface WikiArticle {
  id: string
  title: string
  category: string
  content: string
}

export const wikiArticles: WikiArticle[] = [
  {
    id: 'kurulum-rehberi',
    title: 'Kurulum Rehberi',
    category: 'Başlangıç',
    content: `Assyte Dev ürünlerini sunucunuza kurmak için aşağıdaki adımları takip edin.

## Ön Gereksinimler

- Java 17 veya üzeri (Minecraft pluginleri için)
- Node.js 18+ (Web çözümleri için)
- Discord Bot Token (Discord entegrasyonları için)

## Adım 1: Dosyaları İndirin

Satın aldığınız ürünün dosyalarını Discord sunucumuzdaki #indirmeler kanalından veya size özel olarak gönderilen linkten indirin.

## Adım 2: Sunucuya Yükleyin

Plugin dosyasını (\`.jar\`) Minecraft sunucunuzun \`plugins/\` klasörüne atın. Web çözümleri için dosyaları hosting panelinize yükleyin.

## Adım 3: Sunucuyu Yeniden Başlatın

Sunucunuzu yeniden başlatın. İlk çalıştırmada plugin gerekli klasörleri ve yapılandırma dosyalarını oluşturacaktır.

## Adım 4: Yapılandırma

\`plugins/<ürün-adi>/config.yml\` dosyasını düzenleyerek Discord bot token, veritabanı bilgileri ve diğer ayarları yapılandırın.

## Adım 5: Test Edin

Sunucunuza giriş yaparak ürünün çalıştığını doğrulayın. Herhangi bir sorunla karşılaşırsanız Discord sunucumuzdan destek alabilirsiniz.`
  },
  {
    id: 'discord-bot-baglama',
    title: 'Discord Bot Bağlama',
    category: 'Entegrasyon',
    content: `Ürünlerinizi Discord botunuza bağlamak için aşağıdaki adımları izleyin.

## Discord Developer Portal

1. Discord Developer Portal'a gidin ve botunuzu oluşturun (veya mevcut botu kullanın).
2. Bot token'ınızı kopyalayın.
3. Botunuza gerekli intent'leri (Message Content, Server Members, Presence) aktif edin.

## Yapılandırma

Ürününüzün config dosyasında aşağıdaki ayarları yapın:

\`\`\`yaml
discord:
  token: "BOT_TOKENINIZ"
  guild-id: "SUNUCU_ID"
  log-channel: "LOG_KANALI_ID"
\`\`\`

## Yetkilendirme

Botunuzu sunucunuza eklemek için aşağıdaki linki kullanın:

\`https://discord.com/api/oauth2/authorize?client_id=BOT_CLIENT_ID&permissions=8&scope=bot\`

## Test

\`/test\` komutunu kullanarak bot bağlantısını test edin. Başarılı yanıt alıyorsanız kurulum tamamlanmıştır.`
  },
  {
    id: 'plugin-yapilandirma',
    title: 'Plugin Yapılandırma',
    category: 'Kullanım',
    content: `Ürünlerinizi ihtiyaçlarınıza göre yapılandırma rehberi.

## config.yml Yapısı

Tüm Assyte Dev ürünleri merkezi bir yapılandırma sistemine sahiptir. Ana config dosyası \`plugins/<ürün>/config.yml\` konumunda bulunur.

## Temel Ayarlar

\`\`\`yaml
# Örnek yapılandırma
general:
  language: "tr" # tr, en, de
  prefix: "&b[Assyte] &r"
  debug: false

database:
  type: "sqlite" # sqlite, mysql
  host: "localhost"
  port: 3306
  database: "assyte"
  username: "root"
  password: ""
\`\`\`

## Özelleştirme

Her ürün kendine özgü yapılandırma seçenekleri sunar. Detaylı bilgi için Wiki sayfamızdaki ilgili ürün dökümantasyonunu inceleyebilirsiniz.

## Değişiklikleri Uygulama

Config dosyasında değişiklik yaptıktan sonra \`/<ürün> reload\` komutunu kullanarak değişiklikleri anında uygulayabilirsiniz.`
  },
  {
    id: 'lisans-ve-guncelleme',
    title: 'Lisans ve Güncelleme',
    category: 'Bilgi',
    content: `Ürün lisanslama ve güncelleme politikalarımız.

## Lisanslama

Tüm Assyte Dev ürünleri tek sunucu lisansı ile çalışır. Lisansınız satın aldığınız ürünle birlikte size özel olarak oluşturulur.

- **Standart Lisans**: 1 Minecraft sunucusu / 1 Discord botu için geçerlidir.
- **Premium Lisans**: Sınırsız kullanım hakkı sağlar.

## Güncelleme Politikası

- Tüm güncellemeler Discord sunucumuz üzerinden duyurulur.
- Büyük sürüm güncellemeleri (v1.x → v2.x) ücretlendirilebilir.
- Küçük güncellemeler ve hata düzeltmeleri ücretsizdir.
- Güvenlik yamaları tüm kullanıcılar için ücretsizdir.

## Lisans Süresi

Ürünlerimiz ömür boyu lisans ile satılır. Herhangi bir yıllık yenileme ücreti bulunmamaktadır.`
  },
  {
    id: 'sss',
    title: 'Sık Sorulan Sorular',
    category: 'Destek',
    content: `Sıkça sorulan sorular ve yanıtları.

## Ürünler hangi Minecraft sürümlerini destekliyor?

Tüm pluginlerimiz Paper 1.17+ sürümlerini destekler. Diğer sunucu yazılımları (Spigot, Purpur vb.) ile de uyumludur.

## İade politikası nedir?

Ürünlerimiz dijital olduğu için satın alma sonrası iade yapılmamaktadır. Ancak ürünün çalışmaması durumunda Discord üzerinden destek alabilirsiniz.

## Özel sipariş nasıl verebilirim?

Discord sunucumuzda #ozel-siparis kanalından bize ulaşabilirsiniz. İhtiyaçlarınızı detaylıca belirtin, size özel teklif hazırlayalım.

## Güncellemeler nasıl alınır?

Tüm güncellemeler Discord sunucumuzda duyurulur. Güncel dosyalara #indirmeler kanalından ulaşabilirsiniz.

## Hangi ödeme yöntemlerini kabul ediyorsunuz?

Şu an için PayPal ve kripto para (USDT, BTC) kabul ediyoruz. Özel durumlar için iletişime geçebilirsiniz.

## Teknik destek nasıl alabilirim?

Discord sunucumuzdaki #destek kanalından 7/24 destek alabilirsiniz. Lütfen sorununuzu detaylıca açıklayın ve varsa hata loglarını ekleyin.`
  }
]

export const wikiCategories = [
  'Başlangıç',
  'Entegrasyon',
  'Kullanım',
  'Bilgi',
  'Destek'
] as const
