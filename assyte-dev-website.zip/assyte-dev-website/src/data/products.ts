export interface Product {
  id: string
  name: string
  description: string
  longDescription: string
  category: 'discord-plugin' | 'minecraft' | 'web' | 'custom'
  price: string
  status: 'active' | 'beta' | 'coming-soon'
  features: string[]
  support: boolean
}

export const products: Product[] = [
  {
    id: 'asverify',
    name: 'asVerify',
    description: 'Discord hesap eşleme ve doğrulama plugin sistemi.',
    longDescription: 'asVerify, oyuncuların Discord hesaplarını Minecraft sunucunuzda doğrulamasını sağlayan güçlü bir eşleme sistemidir. Tamamen özelleştirilebilir ve kullanıcı dostu arayüzü sayesinde dakikalar içinde kurulum yapabilirsiniz.',
    category: 'discord-plugin',
    price: '€19.99',
    status: 'active',
    features: [
      'Otomatik Discord-Minecraft eşleme',
      'Kod bazlı doğrulama sistemi',
      'Özelleştirilebilir mesajlar',
      'Çoklu sunucu desteği',
      'Gelişmiş log sistemi',
      'API desteği'
    ],
    support: true
  },
  {
    id: 'asgiveaway',
    name: 'asGiveAway',
    description: 'Discord entegreli, tam otomatik çekiliş plugin sistemi.',
    longDescription: 'asGiveAway, Minecraft sunucunuzda Discord ile tam entegre çekilişler düzenlemenizi sağlar. Katılımcılar, kazanan seçimi ve ödül dağıtımı tamamen otomatiktir.',
    category: 'discord-plugin',
    price: '€14.99',
    status: 'active',
    features: [
      'Discord ile tam entegrasyon',
      'Otomatik kazanan seçimi',
      'Özelleştirilebilir çekiliş süreleri',
      'Katılım koşulları',
      'Birden fazla ödül desteği',
      'Detaylı istatistikler'
    ],
    support: true
  },
  {
    id: 'custom-discord-bot',
    name: 'Özel Discord Bot Altyapısı',
    description: 'Size özel, tamamen sıfırdan geliştirilmiş Discord bot çözümü.',
    longDescription: 'İhtiyaçlarınıza göre tasarlanmış, ölçeklenebilir ve modüler Discord bot altyapısı. Moderasyon, eğlence, yardım veya herhangi bir özel senaryo için bot geliştiriyoruz.',
    category: 'custom',
    price: 'Teklif Al',
    status: 'active',
    features: [
      'Sıfırdan özel geliştirme',
      'Modüler kod yapısı',
      'Veritabanı entegrasyonu',
      'Dashboard arayüzü',
      '7/24 destek',
      'Sürekli güncelleme'
    ],
    support: true
  },
  {
    id: 'minecraft-packet',
    name: 'Minecraft Sunucu Sistem Paketi',
    description: 'Premium Minecraft sunucu sistemleri, pluginler ve altyapı paketi.',
    longDescription: 'Kapsamlı Minecraft sunucu çözümleri paketi. Ekonomi, rank, koruma, oyun sistemleri ve daha fazlası tek bir pakette. Modüler yapısı sayesinde ihtiyacınız olanı seçin.',
    category: 'minecraft',
    price: '€39.99',
    status: 'active',
    features: [
      'Gelişmiş ekonomi sistemi',
      'Rank ve yetki yönetimi',
      'Bölge koruma sistemi',
      'Özel oyun modları',
      'Anti-cheat entegrasyonu',
      'Discord bağlantısı'
    ],
    support: true
  },
  {
    id: 'web-packet',
    name: 'Web Site Kurulum Paketi',
    description: 'Profesyonel web sitesi kurulumu, tema ve altyapı çözümleri.',
    longDescription: 'Sunucunuz için modern ve responsive web sitesi. Oyuncu istatistikleri, mağaza, başvuru sistemi ve daha fazlası hazır şablonlarla veya sıfırdan size özel olarak geliştirilir.',
    category: 'web',
    price: 'Teklif Al',
    status: 'active',
    features: [
      'Responsive tasarım',
      'Sunucu istatistikleri',
      'Online mağaza entegrasyonu',
      'Oyuncu profilleri',
      'Admin paneli',
      'SEO optimizasyonu'
    ],
    support: true
  },
  {
    id: 'asmoderation',
    name: 'asModeration',
    description: 'Gelişmiş Discord moderasyon bot altyapısı ve plugin sistemi.',
    longDescription: 'asModeration, sunucunuzu güvende tutmak için kapsamlı moderasyon araçları sunar. Otomatik filtreleme, uyarı sistemi ve detaylı loglama özellikleriyle donatılmıştır.',
    category: 'discord-plugin',
    price: '€24.99',
    status: 'beta',
    features: [
      'Gelişmiş otomatik moderasyon',
      'Özel filtreleme kuralları',
      'Uyarı ve ceza sistemi',
      'Detaylı log kaydı',
      'Appeal sistemi',
      'Dashboard yönetimi'
    ],
    support: true
  },
  {
    id: 'aslevels',
    name: 'asLevels',
    description: 'Seviye ve XP sistemi ile sunucunuzu canlandırın.',
    longDescription: 'asLevels, oyuncularınıza seviye atlama ve ödül sistemi sunar. Aktif oyuncuları ödüllendirin, liderlik tabloları oluşturun ve topluluğunuzu büyütün.',
    category: 'minecraft',
    price: '€12.99',
    status: 'coming-soon',
    features: [
      'Seviye ve XP sistemi',
      'Liderlik tabloları',
      'Özel ödüller',
      'Discord entegrasyonu',
      'Özelleştirilebilir ayarlar'
    ],
    support: false
  },
  {
    id: 'custom-webapp',
    name: 'Özel Web Uygulaması',
    description: 'İhtiyacınıza yönelik özel web uygulaması ve altyapı çözümleri.',
    longDescription: 'Size özel web uygulamaları, panel sistemleri veya API altyapıları geliştiriyoruz. Modern teknolojilerle, ölçeklenebilir ve güvenli çözümler sunuyoruz.',
    category: 'custom',
    price: 'Teklif Al',
    status: 'active',
    features: [
      'Özel geliştirme',
      'Modern teknoloji stack',
      'API geliştirme',
      'Panel yönetim sistemleri',
      'Veritabanı tasarımı',
      'Performans optimizasyonu'
    ],
    support: true
  }
]

export const categories = [
  { id: 'all', label: 'Tümü' },
  { id: 'discord-plugin', label: 'Discord Pluginleri' },
  { id: 'minecraft', label: 'Minecraft Sistemleri' },
  { id: 'web', label: 'Web Çözümleri' },
  { id: 'custom', label: 'Özel Yazılım' },
] as const

export const storeProducts = products.filter(p => p.status !== 'coming-soon')
